Credits
=======

Inputs is by Zeth, all mistakes are mine.

Thanks to Dave Jones for stick.py which is not only the basis for
Sense HAT stick support in this module but more importantly also
taught me an easier way to parse the Evdev event format in Python:

    https://github.com/RPi-Distro/python-sense-hat/blob/master/sense_hat/stick.py

    https://github.com/waveform80/pisense/blob/master/pisense/stick.py

Thanks to Andy (r4dian) and Jason R. Coombs whose existing (MIT
licenced) Python examples for Xbox 360 controller support on Windows
helped me understand xinput greatly. Xbox 360 controller support on
Windows here is based on their work:

    https://github.com/r4dian/Xbox-360-Controller-for-Python

    http://pydoc.net/Python/jaraco.input/1.0.1/jaraco.input.win32.xinput/
